﻿// Generated public Safari configuration. Never add private server secrets here.
const ComprRuntimeConfig = Object.freeze({
  apiBaseUrl: "https://compr-backend.onrender.com",
  supabaseUrl: "https://taosgvfdnblnopaywimf.supabase.co",
  supabaseAnonKey: "sb_publishable_cZtYQI3ApFTw8kU2a2AoBQ_nGdlSw1W",
  authCallbackUrl: "https://getcompr.nl/auth-callback.html",
  mode: "production",
  betaMode: true,
  betaAccessUrl: "https://getcompr.nl/#beta-access",
  storeReviewUrl: "",
  platform: "safari",
  guestMode: false
});

